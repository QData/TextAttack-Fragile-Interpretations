from .word_merge import WordMerge
from .word_merge_masked_lm import WordMergeMaskedLM
